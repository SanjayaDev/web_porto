<?php 

require "head.php";
require "header.php";
require "sidenav.php";
require "content.php";
require "footer.php";