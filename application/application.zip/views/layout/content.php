<div class="content transition">
  <?php

  if (isset($content)) {
    $this->load->view($content);
  }
  ?>
</div>